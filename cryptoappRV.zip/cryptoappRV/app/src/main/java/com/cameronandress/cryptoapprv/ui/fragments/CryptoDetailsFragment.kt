package com.cameronandress.cryptoapprv.ui.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.cameronandress.cryptoapprv.R
import org.json.JSONObject

class CryptoDetailsFragment : Fragment() {

    private lateinit var cryptoName: TextView
    private lateinit var cryptoSymbol: TextView
    private lateinit var cryptoSupply: TextView
    private lateinit var cryptoPrice: TextView
    private lateinit var cryptoChange: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_crypto_details, container, false)

        // Initialize TextViews
        cryptoName = view.findViewById(R.id.cryptoName)
        cryptoSymbol = view.findViewById(R.id.cryptoSymbol)
        cryptoSupply = view.findViewById(R.id.cryptoSupply)
        cryptoPrice = view.findViewById(R.id.cryptoPrice)
        cryptoChange = view.findViewById(R.id.cryptoChange)

        return view
    }

    @SuppressLint("SetTextI18n")
    fun updateDetails(crypto: JSONObject) {
        cryptoName.text = "Name: ${crypto.getString("name")}"
        cryptoSymbol.text = "Symbol: ${crypto.getString("symbol")}"
        cryptoSupply.text = "Supply: ${crypto.getDouble("supply").toInt()}"
        cryptoPrice.text = "Price (USD): ${"%.2f".format(crypto.getDouble("priceUsd"))}"
        cryptoChange.text = "24H Change (%): ${"%.2f".format(crypto.getDouble("changePercent24Hr"))}"
    }
}
