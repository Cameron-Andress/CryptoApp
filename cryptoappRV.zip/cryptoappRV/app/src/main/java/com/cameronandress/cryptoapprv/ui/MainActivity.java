package com.cameronandress.cryptoapprv.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.cameronandress.cryptoapprv.R;
import com.cameronandress.cryptoapprv.ui.fragments.CryptoDetailsFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Spinner cryptoSpinner;

    private final List<String> cryptoList = new ArrayList<>();
    private final Map<String, JSONObject> cryptoData = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        cryptoSpinner = findViewById(R.id.cryptoSpinner);
        Button refreshButton = findViewById(R.id.refreshButton);

        // Add CryptoDetailsFragment if needed
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new CryptoDetailsFragment())
                    .commit();
        }

        // Set up refresh button click listener
        refreshButton.setOnClickListener(v -> loadCryptoData());

        // Load data initially
        loadCryptoData();
    }

    private void loadCryptoData() {
        RequestQueue queue = Volley.newRequestQueue(this);

        String apiUrl = "https://api.coincap.io/v2/assets";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET, apiUrl, null,
                this::processCryptoData,
                error -> Toast.makeText(this, "Error fetching data: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        );

        queue.add(jsonObjectRequest);
    }

    private void processCryptoData(JSONObject response) {
        try {
            JSONArray dataArray = response.getJSONArray("data");
            cryptoList.clear();
            cryptoData.clear();

            // Parse response and populate lists
            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject crypto = dataArray.getJSONObject(i);
                String name = crypto.getString("name");
                cryptoList.add(name);
                cryptoData.put(name, crypto);
            }

            // Update spinner with new data
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_spinner_item,
                    cryptoList
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            cryptoSpinner.setAdapter(adapter);

            // Set up spinner selection listener
            cryptoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String selectedCrypto = cryptoList.get(position);
                    showCryptoDetails(selectedCrypto);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // No action needed
                }
            });
        } catch (JSONException e) {
            Toast.makeText(this, "Error processing data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showCryptoDetails(String cryptoName) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container);

        if (fragment instanceof CryptoDetailsFragment) {
            try {
                JSONObject cryptoDetails = cryptoData.get(cryptoName);
                if (cryptoDetails != null) {
                    ((CryptoDetailsFragment) fragment).updateDetails(cryptoDetails);
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error displaying details: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
