package com.cameronandress.cryptoapprv

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.cameronandress.cryptoapprv.ui.fragments.CryptoDetailsFragment
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var cryptoSpinner: Spinner
    private lateinit var refreshButton: Button

    private val apiUrl = "https://api.coincap.io/v2/assets"
    private var cryptoList = mutableListOf<String>()
    private var cryptoData = mutableMapOf<String, JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        cryptoSpinner = findViewById(R.id.cryptoSpinner)
        refreshButton = findViewById(R.id.refreshButton)

        // Add CryptoDetailsFragment if needed
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, CryptoDetailsFragment())
                .commit()
        }

        // Set up refresh button click listener
        refreshButton.setOnClickListener {
            loadCryptoData()
        }
    }

    private fun loadCryptoData() {
        val queue = Volley.newRequestQueue(this)

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, apiUrl, null,
            { response ->
                processCryptoData(response)
            },
            { error ->
                Toast.makeText(this, "Error fetching data: ${error.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        )

        queue.add(jsonObjectRequest)
    }

    private fun processCryptoData(response: JSONObject) {
        val dataArray = response.getJSONArray("data")
        cryptoList.clear()
        cryptoData.clear()

        for (i in 0 until dataArray.length()) {
            val crypto = dataArray.getJSONObject(i)
            val name = crypto.getString("name")
            cryptoList.add(name)
            cryptoData[name] = crypto
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cryptoList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        cryptoSpinner.adapter = adapter

        cryptoSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedCrypto = cryptoList[position]

                // Safely find and check the fragment
                val fragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
                if (fragment is CryptoDetailsFragment) {
                    // Update details only if the fragment is of the correct type
                    fragment.updateDetails(cryptoData[selectedCrypto]!!)
                } else {
                    // Log an error or show a message if the fragment is not found or of the wrong type
                    Toast.makeText(
                        this@MainActivity,
                        "Fragment not found or invalid",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                // Handle case when no item is selected
            }
        }
    }
}


